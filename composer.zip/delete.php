<?php
$conn = mysqli_connect('localhost', 'root', '', 'converter');
if (isset($_GET['id'])) {
    $file = $_GET['id'];
    $id = $_GET['user'];
    $fileType = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $fileName = basename($file, $fileType);
    $xlsx = "xlsx/" . $fileName . "xlsx";
    $xml = "xml/" . $file;



        $sql = "DELETE FROM file WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            if (!unlink($xml)) {
                echo("Error deleting $xml");
            } else {
                header("Location:index.php");
                exit();
            }
        } else {
            echo "Error deleting record: " . $conn->error;
        }
} else {
    echo "ok";
}
